#!/usr/bin/env bash
sudo sed -i '/password\"/d' /root/.java/.userPrefs/com/techrove/timeclock/utils/prefs.xml

